

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s3@localhost:50373' % (username, password))
        # where xxxxx is your unique port number
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)
            return True            
        else:
            raise Exception("Nothing to save ...")

# Create method to implement the R in CRUD
    def read_all(self, data):
        cursor = self.database.animals.find(data, {'_id':False} )
        
        return cursor
    
    def read(self, data):
        return self.database.animals.find_one(data)
    
    
    
    def update(self,data)
    result = self.database.update_many
        return result
    
    def delete(self,data):
        result = self.database.delete_many(key_value_pairs)
            return dumps(self.read(key_value_pairs))
        